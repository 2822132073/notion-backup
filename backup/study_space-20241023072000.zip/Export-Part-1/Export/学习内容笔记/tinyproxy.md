# tinyproxy

[tinyproxy/tinyproxy: tinyproxy - a light-weight HTTP/HTTPS proxy daemon for POSIX operating systems (github.com)](https://github.com/tinyproxy/tinyproxy)

[推荐一款轻量级 HTTP/HTTPS 代理 TinyProxy-腾讯云开发者社区-腾讯云](https://cloud.tencent.com/developer/article/1475747)

[Tinyproxy](https://tinyproxy.github.io/)

之前尝试过使用nginx对内网机器进行代理，但是失败了，一直提示405，找了很多办法没办法解决，然后就准备找一些其他更加专业的软件进行代理，于是找到了`tinyproxy` ，它可以代理内网的请求，做到正向代理的功能

## 安装

> 一般来说，ubuntu都有这个包，而centos系的产品需要安装epel仓库
> 

```yaml
# 需要 EPEL 仓库
yum install -y tinyproxy
# 或者
apt-get -y install tinyproxy
```

## 配置

`/etc/tinyproxy/tinyproxy.conf`

```yaml
Port 8888
Listen 0.0.0.0
Timeout 600
Allow 192.168.1.0/24
```

> 设置了监听的地址，以及允许监听的地址
> 

## 启动

```yaml
systemctl start tinyproxy
systemctl enable tinyproxy
```

## 测试

> `-x` ：设置代理地址
`-k` ：跳过ssl
`-v` ：显示具体信息
> 

```yaml
curl -k http://baidu.com/ -v -x http://192.168.1.105:8888/
```