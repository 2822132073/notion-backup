# golang自定义log

> 目录结构
> 

```go
├─internal
│  ├─config
│  │      main.go
│  │
│  ├─controller
│  │      ServerStatus.go
│  │      ServerStatus_test.go
│  │      uploadFile.go
│  │      webSocket.go
│  │
│  └─log
│          func.go
│          init.go

```

> config/main.go
> 

```go
package config

import (
	"bytes"
	"github.com/a8m/envsubst"
	"github.com/mcuadros/go-defaults"
	"github.com/rs/zerolog"
	"github.com/spf13/viper"
	"os"
)

type Nginx struct {
	BinPath    string
	ConfigPath string
}

type Gin struct {
	Port   int    `default:"8080"`
	Server string `default:"0.0.0.0"`
}
type Config struct {
	Nginx Nginx
	Gin   Gin
	Log   Log
}
type Log struct {
	NoColor     bool   `default:"false"`
	TimeFormat  string `default:"2006-01-02 15:04:05"`
	Level       string `default:"info"`
	ConfFile    string
	Dir         string `default:"."`
	OnlyConsole bool   `default:"true"`
}

var Conf Config

func LoadConfig() *viper.Viper {
	defaults.SetDefaults(&Conf)

	v := viper.New()

	consoleWriter := zerolog.ConsoleWriter{Out: os.Stdout, TimeFormat: "2006-01-02 15:04:05"}
	logger := zerolog.New(consoleWriter).With().Timestamp().Logger()
	// load config from file
	configFile := ""
	if len(os.Args) == 2 {
		configFile = os.Args[1]

	} else {
		configFile = "./server.yml"
	}
	logger.Info().Msgf("load config from file: %s", configFile)

	buf, err := envsubst.ReadFile(configFile)
	if err != nil {
		logger.Error().Msgf("failed to read config file: %v", err)
		os.Exit(1)
	}
	v.SetConfigType("yaml")
	err = v.ReadConfig(bytes.NewReader(buf))
	if err != nil {
		logger.Error().Msgf("failed to read config file: %v", err)
		os.Exit(1)
	}
	// unmarshal config
	err = v.Unmarshal(&Conf)
	if err != nil {
		panic(err)
	}
	return v
}

```

> log/init.go
> 

```go
package log

import (
	"fmt"
	"io"
	"os"
	"path/filepath"

	"github.com/rs/zerolog"
)

var logger zerolog.Logger

func Init(level string, file string, dir string, onlyConsole bool) {
	// log level
	switch level {
	case "debug":
		zerolog.SetGlobalLevel(zerolog.DebugLevel)
	case "info":
		zerolog.SetGlobalLevel(zerolog.InfoLevel)
	case "warn":
		zerolog.SetGlobalLevel(zerolog.WarnLevel)
	default:
		panic(fmt.Sprintf("unknown log level: %s", level))
	}

	// dir
	dir, err := filepath.Abs(dir)
	if err != nil {
		panic(fmt.Sprintf("failed to determine current directory: %v", err))
	}
	if _, err := os.Stat(dir); os.IsNotExist(err) {
		err = os.MkdirAll(dir, 0777)
		if err != nil {
			panic(fmt.Sprintf("mkdir failed. dir=[%s], error=[%v]", dir, err))
		}
	}
	path := filepath.Join(dir, file)

	// log file
	writers := make([]io.Writer, 0)
	consoleWriter := zerolog.ConsoleWriter{Out: os.Stdout, TimeFormat: "2006-01-02 15:04:05"}
	writers = append(writers, consoleWriter)
	if !onlyConsole {
		fileWriter, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0666)
		if err != nil {
			panic(fmt.Sprintf("open log file failed. file=[%s], err=[%s]", path, err))
		}
		writers = append(writers, fileWriter)
	}

	multi := zerolog.MultiLevelWriter(writers...)
	logger = zerolog.New(multi).With().Timestamp().Logger()
	Infof("log_level: [%v], log_file: [%v]", level, file)
}

```

> log/func.go
> 

```go
package log

import (
	"fmt"
	"github.com/go-stack/stack"
	"os"
)

func Debugf(format string, args ...interface{}) {
	logger.Debug().Msgf(format, args...)
}

func Infof(format string, args ...interface{}) {
	logger.Info().Msgf(format, args...)
}

func Warnf(format string, args ...interface{}) {
	logger.Warn().Msgf(format, args...)
}

func Panicf(format string, args ...interface{}) {
	frames := stack.Trace()
	errMsg := fmt.Sprintf(format, args...)
	for _, frame := range frames {
		frameStr := fmt.Sprintf("%+v", frame)
		errMsg += fmt.Sprintf("\n\t\t\t%v -> %n()", frameStr, frame)
	}
	logger.Error().Msgf(errMsg)
	os.Exit(1)
}

```

## 使用

> 在main.go中添加，加载log之后，就可以在其他的文件中导入，该库，然后使用
> 

```go
	config.LoadConfig()
	log.Init(config.Conf.Log.Level, config.Conf.Log.ConfFile, config.Conf.Log.Dir, config.Conf.Log.OnlyConsole)
```