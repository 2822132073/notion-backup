# 编译安装openresty

> 环境 ：ubuntu
> 

```bash
apt-get install libpcre3-dev \
    libssl-dev perl make build-essential curl make \
    libpq-dev zlib1g-dev libxml2-dev libxslt1-dev libgd-dev\
    libgeoip-dev libatomic-ops-dev libperl-dev
```

```bash
./configure -j8 --with-no-pool-patch --with-http_iconv_module  --with-http_postgres_module     --with-select_module --with-poll_module --with-threads --with-file-aio --with-http_ssl_module --with-http_v2_module --with-http_v3_module --with-http_realip_module --with-http_addition_module --with-http_xslt_module --with-http_xslt_module=dynamic --with-http_image_filter_module --with-http_image_filter_module=dynamic --with-http_geoip_module --with-http_geoip_module=dynamic --with-http_sub_module --with-http_dav_module --with-http_flv_module --with-http_mp4_module --with-http_gunzip_module --with-http_gzip_static_module --with-http_auth_request_module --with-http_random_index_module --with-http_secure_link_module --with-http_degradation_module --with-http_slice_module --with-http_stub_status_module --with-http_perl_module --with-http_perl_module=dynamic  --with-mail --with-mail=dynamic --with-mail_ssl_module --with-stream --with-stream=dynamic --with-stream_ssl_module --with-stream_realip_module --with-stream_geoip_module --with-stream_geoip_module=dynamic --with-stream_ssl_preread_module   --with-compat --with-pcre --with-pcre-jit --with-libatomic
```

```bash
mkdir -p /usr/local/openresty/site/lualib /usr/local/openresty/site/pod /usr/local/openresty/site/manifest
ln -sf /usr/local/openresty/nginx/sbin/nginx /usr/local/openresty/bin/openresty

```

```bash
alias openresty='/usr/local/openresty/bin/openresty -c /usr/local/openresty/nginx/conf/nginx.conf'
```