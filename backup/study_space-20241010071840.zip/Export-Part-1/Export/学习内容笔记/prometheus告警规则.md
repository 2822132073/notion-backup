# prometheus告警规则

[常用prometheus告警规则模板（三）【转】 - paul_hch - 博客园](https://www.cnblogs.com/paul8339/p/13633499.html#_label6)

[Prometheus常用告警规则_promethus alert expr-CSDN博客](https://blog.csdn.net/wangshui898/article/details/120321640)

[Awesome Prometheus alerts](https://samber.github.io/awesome-prometheus-alerts/rules)

```bash

```

[alertmanager通过dingding告警](prometheus%E5%91%8A%E8%AD%A6%E8%A7%84%E5%88%99%20119526468f4b808aaa47ddf28acdd0f0/alertmanager%E9%80%9A%E8%BF%87dingding%E5%91%8A%E8%AD%A6%20119526468f4b801fb8aff7eb7bb1a21b.md)