# openresty

[Lua Ngx API - OpenResty Reference](https://openresty-reference.readthedocs.io/en/latest/Lua_Nginx_API/#print)

通过lua动态设置代理

[Url change when using openresty proxy_pass with Variable · Issue #441 · openresty/lua-nginx-module](https://github.com/openresty/lua-nginx-module/issues/441)

![image.png](openresty%20116526468f4b806c91a2e7fd3b0ccb2d/image.png)

[二进制安装openresty](openresty%20116526468f4b806c91a2e7fd3b0ccb2d/%E4%BA%8C%E8%BF%9B%E5%88%B6%E5%AE%89%E8%A3%85openresty%20116526468f4b81a082a1cbbf0948265b.md)

[map的使用实验](openresty%20116526468f4b806c91a2e7fd3b0ccb2d/map%E7%9A%84%E4%BD%BF%E7%94%A8%E5%AE%9E%E9%AA%8C%20116526468f4b81d2ad2fd32db4aaba4e.md)

[vim开启nginx配置语法高亮](openresty%20116526468f4b806c91a2e7fd3b0ccb2d/vim%E5%BC%80%E5%90%AFnginx%E9%85%8D%E7%BD%AE%E8%AF%AD%E6%B3%95%E9%AB%98%E4%BA%AE%20116526468f4b81e881f0f2adcf84b2d3.md)

[openresty读取文件](openresty%20116526468f4b806c91a2e7fd3b0ccb2d/openresty%E8%AF%BB%E5%8F%96%E6%96%87%E4%BB%B6%20116526468f4b819781a0efcbbd2cbc27.md)