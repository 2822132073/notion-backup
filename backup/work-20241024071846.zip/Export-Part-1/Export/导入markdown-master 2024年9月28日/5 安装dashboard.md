# 5.安装dashboard

在安装dashboard之前需要安装mgr，这个在第一步就安装了

1. 安装`ceph-mgr-dashboard`
    
    ```
    [root@ceph-0 /etc/ceph]# apt install ceph-mgr-dashboard
    ```
    
2. 启动dashboard
    
    ```
    [root@ceph-0 /etc/ceph]# ceph mgr module enable dashboard
    ```
    
3. 关闭dashboard的ssl功能(非必须，如果不关闭，需要自签证书)
    
    ```
    ceph config set mgr mgr/dashboard/ssl false
    ```
    
4. 设置dashboard端口
    
    ```
    ceph config set mgr mgr/dashboard/$name/server_addr 10.0.0.80
    ceph config set mgr mgr/dashboard/$name/server_port 8080
    ```
    
5. 为dashboard创建用户
    
    ```
    ceph dashboard ac-user-create admin admin administrator --force-password
    ```
    

![https://cdn.jsdelivr.net/gh/2822132073/image/202404130018062.png](https://cdn.jsdelivr.net/gh/2822132073/image/202404130018062.png)

image-20240413001838742