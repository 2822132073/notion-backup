# ubuntun18.04无法使用nmcli管理

# ubuntun18.04无法使用nmcli管理

[TOC]

## 起因

> 在安装ubuntun18.04时,在安装完成后,想使用nmcli管理网络,下载network-manager后,查看连接状态,状态为无法管理
> 

## 原因

> ubuntun18.04默认使用netplan管理网络,在我查看interface文件时,这个文件为空,所以,需要在netplan下进行修改
> 

## 解决

> 在这个文件下加入一行renderer: NetworkManager,注意缩进
> 

> 注意,这个文件只能有一下内容,不然NetworManager不生效
> 

```yaml
[root@root ~]# cat /etc/netplan/00-installer-config.yaml# This is the network config written by 'subiquity'network:  renderer: NetworkManager  version: 2
```

```
[root@root ~]# netplan try
Do you want to keep these settings?
Press ENTER before the timeout to accept the new configuration
Changes will revert in 118 seconds
Configuration accepted.
[root@root ~]# netplan apply
```

### NetworkManager配置文件位置

> 我是用NetworkManager修改IP,在/etc/netplan/并没有进行修改,Network-Manager是对/etc/NetworkManager/system-connections进行的修改,下面的每一个文件名都对应着一个con-name
>