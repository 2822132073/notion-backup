# Python调用Openstack

# Python调用Openstack

## 安装相应的库

```python
pip install openstacksdk
pip install python-novaclient
```