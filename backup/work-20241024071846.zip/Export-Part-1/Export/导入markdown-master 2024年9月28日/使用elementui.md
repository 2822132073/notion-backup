# 使用elementui

## 安装element-ui

> 在按需引入之前,必须安装element-ui
> 

```jsx
 npm install element-plus --save
```

### 完整引入[#](https://element-plus.org/zh-CN/guide/quickstart.html#%E5%AE%8C%E6%95%B4%E5%BC%95%E5%85%A5)

如果你对打包后的文件大小不是很在乎，那么使用完整导入会更方便。

```jsx
// main.tsimport { createApp } from 'vue'import ElementPlus from 'element-plus'import 'element-plus/dist/index.css'import App from './App.vue'const app = createApp(App)
app.use(ElementPlus)
app.mount('#app')
```

### Volar 支持[#](https://element-plus.org/zh-CN/guide/quickstart.html#volar-%E6%94%AF%E6%8C%81)

如果您使用 Volar，请在 `tsconfig.json` 中通过 `compilerOptions.type` 指定全局组件类型。

```jsx
// tsconfig.json{
  "compilerOptions": {
    // ...    "types": ["element-plus/global"]
  }
}
```

### 按需导入[#](https://element-plus.org/zh-CN/guide/quickstart.html#%E6%8C%89%E9%9C%80%E5%AF%BC%E5%85%A5)

您需要使用额外的插件来导入要使用的组件。

### 自动导入推荐[#](https://element-plus.org/zh-CN/guide/quickstart.html#%E8%87%AA%E5%8A%A8%E5%AF%BC%E5%85%A5-%E6%8E%A8%E8%8D%90)

首先你需要安装`unplugin-vue-components` 和 `unplugin-auto-import`这两款插件

```bash
npm install -D unplugin-vue-components unplugin-auto-import elemen
```

然后把下列代码插入到你的 `Vite` 或 `Webpack` 的配置文件中

### Vite[#](https://element-plus.org/zh-CN/guide/quickstart.html#vite)

```jsx
// vite.config.tsimport { defineConfig } from 'vite'import AutoImport from 'unplugin-auto-import/vite'import Components from 'unplugin-vue-components/vite'import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'export default defineConfig({
  // ...  plugins: [
    // ...    AutoImport({
      resolvers: [ElementPlusResolver()],    }),    Components({
      resolvers: [ElementPlusResolver()],    }),  ],})
```