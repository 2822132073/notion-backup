# 4.添加mds

> 下列步骤需要用到ceph命令，需要用到ceph.conf和ceph.client.admin.keyring,提前拷贝到执行命令的机器上
> 
1. 创建mds文件夹
    
    ```
    [root@ceph-0 /etc/ceph]# mkdir -p /var/lib/ceph/mds/ceph-ceph-0
    ```
    
2. 创建keyring
    
    ```
    [root@ceph-0 /etc/ceph]# ceph-authtool --create-keyring /var/lib/ceph/mds/ceph-ceph-0/keyring --gen-key -n mds.ceph-0
    creating /var/lib/ceph/mds/ceph-ceph-0/keyring
    ```
    
3. 导入keyring并且设置权限
    
    ```
    [root@ceph-0 /etc/ceph]# ceph auth add mds.ceph-0 osd "allow rwx" mds "allow *" mon "allow profile mds" -i /var/lib/ceph/mds/ceph-ceph-0/keyring
    added key for mds.ceph-0
    
    ```
    
4. 修改配置文件
    
    ```
    [root@ceph-0 /etc/ceph]# cat /etc/ceph/ceph.conf
    [global]
    fsid = 8a212a0e-0fb5-4f4a-a1ee-53d7b3783a64
    mon_initial_members = ceph-0
    mon_host = 10.0.0.80
    public_network = 10.0.0.0/24
    auth_cluster_required = cephx
    auth_service_required = cephx
    auth_client_required = cephx
    osd_pool_default_size = 3
    osd_pool_default_min_size = 2
    osd_pool_default_pg_num = 333
    osd_crush_chooseleaf_type = 1
    
    [mds.ceph-0]
    host = ceph-0
    ```
    
5. 启动mds
    
    ```
    [root@ceph-0 /etc/ceph]# ceph-mds --cluster ceph -i ceph-0 -m 10.0.0.80:6789
    starting mds.ceph-0 at
    ```
    
6. 查看是否启动成功
    
    ```
    [root@ceph-0 /etc/ceph]# ceph mds stat
     1 up:standby
    ```