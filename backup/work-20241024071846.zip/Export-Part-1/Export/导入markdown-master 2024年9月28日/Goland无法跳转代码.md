# Goland无法跳转代码

![https://cdn.jsdelivr.net/gh/2822132073/image/202406252133900.png](https://cdn.jsdelivr.net/gh/2822132073/image/202406252133900.png)

img

无法进行函数查看,并且无代码提示,无法查看源码

但是可以运行

我们可以

![https://cdn.jsdelivr.net/gh/2822132073/image/202406252133229.png](https://cdn.jsdelivr.net/gh/2822132073/image/202406252133229.png)

img

```
go mod vendor
```

出现`vendor`文件夹后,差不多就可以了

![https://cdn.jsdelivr.net/gh/2822132073/image/202406252133163.png](https://cdn.jsdelivr.net/gh/2822132073/image/202406252133163.png)

img

![https://cdn.jsdelivr.net/gh/2822132073/image/202406252133018.png](https://cdn.jsdelivr.net/gh/2822132073/image/202406252133018.png)

img

这样就可以了

![https://cdn.jsdelivr.net/gh/2822132073/image/202406252133415.png](https://cdn.jsdelivr.net/gh/2822132073/image/202406252133415.png)

img

如果还是无法进行跳转,查看Goland的Settings里面的这个是否勾选,没有勾选,勾选这个就行

![https://cdn.jsdelivr.net/gh/2822132073/image/202406252133636.png](https://cdn.jsdelivr.net/gh/2822132073/image/202406252133636.png)

image-20220508221015085