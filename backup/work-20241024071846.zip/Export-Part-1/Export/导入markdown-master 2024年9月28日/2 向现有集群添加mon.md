# 2.向现有集群添加mon

[文档地址](https://docs.ceph.com/en/reef/rados/operations/add-or-rm-mons/)

在上一步，已经安装了一个mon，现在想要完成一个完整的集群（生产可用），需要再添加两个（保证mon的个数为奇数个）

> 想要添加新的mon，直接重复下列步骤
> 
1. 创建新mon的数据目录（在新的mon主机上创建）
    
    > 这步可以不进行，在下面的步骤会自动创建，可能是版本问题
    > 
    
    ```
    #sudo mkdir /var/lib/ceph/mon/ceph-{mon-id}
    [root@ceph-1 ~]# mkdir /var/lib/ceph/mon/ceph-ceph-1 -p
    ```
    
2. 创建一个临时目录，包含了一些创建过程中的临时文件，不能是之前创建的数据目录，可以直接使用 `/tmp`，（在已经创建mon的主机中）
    
    ```
    mkdir /tmp/ceph/
    ```
    
3. 从mon之中去的keyring
    
    ```
    [root@ceph-0 /tmp/ceph]# ceph auth get mon. -o /tmp/ceph/keyring
    exported keyring for mon.
    ```
    
4. 从mon中去的monmap
    
    ```
    [root@ceph-0 /tmp/ceph]# ceph mon getmap -o /tmp/ceph/monmap
    got monmap epoch 1
    ```
    
5. 将monmap和keyring以及配置文件传输到新的mon主机上
    
    ```
    [root@ceph-0 /tmp/ceph]# scp ./* ceph-1:/tmp/
    [root@ceph-0 /tmp/ceph]# scp /etc/ceph/ceph.conf  ceph-1:/etc/ceph/ceph.conf
    ```
    
6. 创建新的mon的数据目录，以及初始化数据
    
    ```
    [root@ceph-1 /tmp]# sudo ceph-mon -i ceph-1 --mkfs --monmap /tmp/monmap --keyring /tmp/keyring
    ```
    
7. 启动mon
    
    > 启动会自动加入集群
    > 
    
    ```
    [root@ceph-1 /tmp]# ceph-mon -i ceph-1 --public-addr 10.0.0.81
    ```