# Elasticsearch安装

# Es初始必须配置

[TOC]

## 数据存储目录

> path.data: 数据存储的目录
path.logs: 日志存储的目录
> 

## 节点类型设置

> node.master:节点是否为主节点
node.data: 节点是否为数据节点
node.ingest: 节点是否为
true或者false
> 

## 如何发现节点(后续节点加入集群需要配置此项配置)

> es在配置中有一项配置是discovery.seed_hosts,这项配置的内容为master节点的地址,
地址可以是:IPV4,IPv6,域名,如果DNS解析可以解析到多个IP地址,es会应用所有的地址,
所有的地址必须按照host:port或host的形式指定,如果未指定port,默认为9300
> 
> 
> 实例:
> 

```
discovery.seed_hosts: ["192.168.1.2","192.168.1.6:5566","fsl.com"]
```

## 设置集群中可以参与选举的节点位置(在第一次引导集群时)

> cluster.initial_master_nodes:在第一次引导集群时,此列表中的主机将可以参与选举,不在此列的主机
无法参与选举,在第一次引导集群完成后,可以将此项配置删除
实例:
> 

```
cluster.initial_master_nodes: ["10.0.0.91","10.0.0.92"]
```

## 集群名称

> cluster.name:如果在局域网中有多个elasticsearch集群,cluster.name将会是集群的唯一标识符
> 

## 节点名称

> node.name:默认为节点的主机名
> 

## 绑定地址

> network.host: 绑定的地址,默认为127.0.0.1,绑定全部ip地址为0.0.0.0
> 

## 客户端访问端口

> http.port: http客户端访问的端口,可以指定当个端口,也可以指定一个范围,当取值是一个范围时,
将绑定范围中第一个可用地址
> 

> 默认:http.port: 9200-9300
> 

## 节点将相互通信的端口

> transport.port:节点将相互通信,可以指定当个端口,也可以指定一个范围,当取值是一个范围时,
将绑定范围中第一个可用地址,如果在master节点上,要设置为单一值,不能是范围
> 

> 默认: 9300-9400
>