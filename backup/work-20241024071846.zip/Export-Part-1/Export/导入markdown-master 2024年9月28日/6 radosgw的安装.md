# 6.radosgw的安装

[文档地址](https://docs.ceph.com/en/quincy/install/manual-deployment/#manually-installing-radosgw)

> 由于之前安装时使用的是15.2.0的版本进行安装，安装过程中出现了一些问题，所以就没写这个文档，建议还是使用cephadm进行安装。这个手动安装还是用来熟悉组件使用的
>