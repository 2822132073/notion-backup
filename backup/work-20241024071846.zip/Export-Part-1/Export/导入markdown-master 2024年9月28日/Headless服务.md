# Headless服务

# Headless服务

## 实验manifest

### busybox

```yaml
apiVersion: v1kind: Podmetadata:  name: busybox  namespace: test-esspec:  containers:  - image: busybox    command:      - sleep      - "360000"    imagePullPolicy: IfNotPresent    name: busybox
```

### StatefulSet

```yaml
apiVersion: apps/v1kind: StatefulSetmetadata:  name: web  namespace: test-esspec:  podManagementPolicy: Parallel  selector:    matchLabels:      app: nginx  serviceName: ng-svc-headless  replicas: 3  template:    metadata:      labels:        app: nginx-pod    spec:      containers:      - name: nginx        image: nginx:1.17.1        ports:        - containerPort: 80          name: web
```

### deploy

```yaml
apiVersion: apps/v1kind: Deploymentmetadata:  name: ng-deployment  namespace: test-esspec:  replicas: 3  selector:    matchLabels:      app: nginx-pod  template:    metadata:      labels:        app: nginx-pod    spec:      containers:      - name: nginx        image: nginx:1.17.1        ports:        - containerPort: 80
```

### SVC-clusterIP

```yaml
apiVersion: v1kind: Servicemetadata:  namespace: test-es  name: ng-svc  labels:    app: nginx-svcspec:  ports:  - port: 80    name: web  selector:    app: nginx-pod
```

### SVC-Headless

```yaml
apiVersion: v1kind: Servicemetadata:  namespace: test-es  name: ng-svc-headless  labels:    app: nginx-svcspec:  ports:  - port: 80    name: web  clusterIP: None  selector:    app: nginx-pod
```

### 结论

> headless与clusterIP区别在于,当向clusterIP发起请求时,kube-proxy,一个clusterIP,然后通过这个clusterIP向后端负载均衡
而Headless确实不走kube-proxy,直接由dns返回后端pod的IP
而且在StatefulSet中可以通过域名访问到每一个pod
> 

### 过程

> 将以上manifest应用一下,在此名称空间下,找到一个可以curl和ping的pod,
在进行实验时,需要修改每个pod下/usr/share/nginx/html/index.html,将其修改为具有标识性的内容
> 

```
[elasticsearch@test-master-0 ~]$ curl ng-svc
2
[elasticsearch@test-master-0 ~]$ curl ng-svc
1
[elasticsearch@test-master-0 ~]$ curl ng-svc
3
```

> 先对clusterIP进行访问,可以访问得到
> 

```
[elasticsearch@test-master-0 ~]$ curl ng-svc-headless
1
[elasticsearch@test-master-0 ~]$ curl ng-svc-headless
2
[elasticsearch@test-master-0 ~]$ curl ng-svc-headless
3
```

> 再对headless进行访问,也可以访问得到
> 

```
lasticsearch@test-master-0 ~]$ ping ng-svc-headless
PING ng-svc-headless.test-es.svc.cluster.local (10.42.248.158) 56(84) bytes of data.
64 bytes from 10-42-248-158.ng-svc.test-es.svc.cluster.local (10.42.248.158): icmp_seq=1 ttl=62 time=0.337 ms
[elasticsearch@test-master-0 ~]$ ping ng-svc-headless
PING ng-svc-headless.test-es.svc.cluster.local (10.42.20.6) 56(84) bytes of data.
64 bytes from 10-42-20-6.ng-svc.test-es.svc.cluster.local (10.42.20.6): icmp_seq=1 ttl=62 time=0.463 ms
[elasticsearch@test-master-0 ~]$ ping ng-svc-headless
PING ng-svc-headless.test-es.svc.cluster.local (10.42.160.180) 56(84) bytes of data.
64 bytes from 10-42-160-180.ng-svc.test-es.svc.cluster.local (10.42.160.180): icmp_seq=1 ttl=62 time=0.259 ms
```

> 对headless进行ping,可以得到后端的IP
> 

```
[elasticsearch@test-master-0 ~]$ ping ng-svc
PING ng-svc.test-es.svc.cluster.local (10.43.12.65) 56(84) bytes of data.
```

> 对Cluster进行访问,可以得到ClusterIP而无法得到后端podIP
> 

```
[root@cq49 ~]# kubectl get svc -n test-es ng-svc
NAME     TYPE        CLUSTER-IP    EXTERNAL-IP   PORT(S)   AGE
ng-svc   ClusterIP   10.43.12.65   <none>        80/TCP    21m
```

### StatefulSet

> 在进行实验时,需要修改每个pod下/usr/share/nginx/html/index.html,将其修改为具有标识性的内容
> 

这样就可以通过域名来对应一个个的`pod`,如果在他们`sts`内部,还可以不使用`svcName`,直接使用`podName`去访问`pod`

```
[elasticsearch@test-master-0 ~]$ curl ng-sts-0.ng-svc-headless
1
[elasticsearch@test-master-0 ~]$ curl ng-sts-1.ng-svc-headless
2
[elasticsearch@test-master-0 ~]$ curl ng-sts-2.ng-svc-headless
3
```