# 动态修改nginx配置

https://github.com/tufanbarisyildirim/gonginx/blob/master/examples/update-directive/main.go

## 设想的功能

- [ ]  通过api的方式获取，修改upstream配置
- [ ]