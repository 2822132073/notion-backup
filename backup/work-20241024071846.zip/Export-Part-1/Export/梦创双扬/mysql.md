# mysql

### 创建主从复制用户

```yaml
//mysql8授权用户需要先创建，创建和授权同一条语句的话会报错
create user slave@'%' identified by '123456';
//再授权
GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION;
//刷新
flush privileges;
```

## 在mysql master节点获取主从命令

```yaml

file=`mysql -uroot -pDreamSoft_123 -e "show master status\G" |grep File |awk '{print $2}'`
pos=`mysql -uroot -pDreamSoft_123 -e "show master status\G" |grep Position |awk '{print $2}'`
user=slave
pass=DreamSoft_123
host="172.16.165.70"
echo "change master to master_host='$host',master_user='$user',master_password='$pass',master_log_file='$file',master_log_pos=$pos, get_master_public_key=1;"
```

> get_master_public_key解决mysql8，**Authentication plugin ‘caching_sha2_password‘ reported error问题，**[MySQL :: MySQL 8.0 Reference Manual :: 15.4.2.1 CHANGE MASTER TO Statement](https://dev.mysql.com/doc/refman/8.0/en/change-master-to.html)
> 

## 1449 - The user specified as a definer ('mysql.infoschema'@localhost') does not exist

```yaml
# 首先检查一下mysql中是否有该用户
use mysql;
select * from user where user="mysql.infoschema";
# 如果存在就先删除他,删除这个的所有用户，无论什么主机
drop user 'mysql.infoschema'@'%';
# 然后创建这个用户
CREATE USER 'mysql.infoschema'@'%' IDENTIFIED BY '123456';
grant all privileges on *.* to 'mysql.infoschema'@'%'; 
```