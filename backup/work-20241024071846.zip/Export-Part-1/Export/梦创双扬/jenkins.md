# jenkins

[jenkins添加ssh server](jenkins%20128a04ce7f0c80939c18df55774fe8bd/jenkins%E6%B7%BB%E5%8A%A0ssh%20server%20128a04ce7f0c801ca972c87955ea35ba.md)

[安卓内网发包过程](jenkins%20128a04ce7f0c80939c18df55774fe8bd/%E5%AE%89%E5%8D%93%E5%86%85%E7%BD%91%E5%8F%91%E5%8C%85%E8%BF%87%E7%A8%8B%20129a04ce7f0c80e9a6bbca02b27cc6e6.md)