# ansible

### 查询机器上chat服务状态

```yaml
ansible -i /root/ansible/hosts web -mshell -a"ps -ef|grep chat|egrep -v 'grep|bash'|awk '{print \$NF}'"
```

### 查询机器上ai服务执行状态

```yaml
ansible -i /root/ansible/hosts web -mshell -a"ps -ef|grep ai-0.0|egrep -v 'grep|bash'|awk '{print \$NF}'"
```

### 查询机器上es服务执行状态

```yaml
ansible -i /root/ansible/hosts web -mshell -a"ps -ef|grep userprofile-0.0|egrep -v 'grep|bash'|awk '{print \$NF}'"
```

### 查询机器上的端口状态

```yaml
ansible -i /root/ansible/hosts web -mshell -a"ss -luntp|egrep '18080|18888|8181|9000'"
```

```bash
SELECT 13
cursor=0
while true do
    keys=$(redis-cli  SCAN ${cursor} MATCH "Chat:Online:jwtCheck:*" COUNT 1000)
    cursor=$(echo $keys | cut -d ' ' -f 1)
    keys=$(echo$keys | cut -d ' ' -f 2-)
    if [ "$keys" != "" ]; then
        redis-cli  DEL $keys
    fi
    if [ "$cursor" == "0" ]; then
        break
    fi
done

```

[串行执行](ansible%20101a04ce7f0c8049acc7c71895f50f05/%E4%B8%B2%E8%A1%8C%E6%89%A7%E8%A1%8C%2011ca04ce7f0c809e8429c79805cd880f.md)

### 灰度发布

```yaml
---
- name: "首先发布3台机器"
  hosts: web-pre
  gather_facts: false
  vars_files:
    - vars/ai-server.yml
  tasks:
    - name: Copy files_mysql to remote hosts
      synchronize:
        # 需要在目录后面加上斜杠才是同步两个目录
        src: "{{ SRC_PATH }}/"
        dest: "{{ DEST_PATH }}/"
        recursive: yes
        archive: yes
        delete: yes
        checksum: yes
        compress: yes
    - name: start service
      shell: "./{{ SCRIPT_NAME }} {{ JAR_NAME }}"
      args:
        chdir: "{{ DEST_PATH }}"
        executable: "/bin/bash"
    - name: "检查状态端口"
      ansible.builtin.wait_for:
        port: "{{ item.1  }}"
        host: "{{ item.0 }}"
        timeout: "{{ WAIT_FOR_TIME_OUT }}"
      with_cartesian:
        - "{{ groups['web-pre'] }}"
        - "{{ CHECK_PORT }}"
- name: "然后发布4台机器"
  hosts: web-post
  gather_facts: false
  vars_files:
    - vars/ai-server.yml
  tasks:
    - name: Copy files_mysql to remote hosts
      synchronize:
        # 需要在目录后面加上斜杠才是同步两个目录
        src: "{{ SRC_PATH }}/"
        dest: "{{ DEST_PATH }}/"
        recursive: yes
        archive: yes
        delete: yes
        checksum: yes
        compress: yes
    - name: "启动服务"
      shell: "./{{ SCRIPT_NAME }} {{ JAR_NAME }}"
      args:
        chdir: "{{ DEST_PATH }}"
        executable: "/bin/bash"
    - name: "检查状态端口"
      wait_for:
        port: "{{ item.1  }}"
        host: "{{ item.0 }}"
        timeout: "{{ WAIT_FOR_TIME_OUT }}"
      with_cartesian:
        - "{{ groups['web-post'] }}"
        - "{{ CHECK_PORT }}"

```

```yaml
JAR_NAME: ai-0.0.1-SNAPSHOT-2024-09-23.jar
DEST_PATH: /data/ai-server
SRC_PATH: /data/ai-server
SCRIPT_NAME: run.sh
WAIT_FOR_TIME_OUT: 300
CHECK_PORT:
  - 9000
```

```yaml
---
- name: "分发chat相关文件"
  hosts: web
  vars:
    JAR_NAME: a.jar
    DEST_PATH: /data/axchat
    SRC_PATH: /data/axchat
    HEALTH_API: http://127.0.0.1:18080/api/health/getInfo
    SCRIPT_NAME: run.sh
    RUN_OPTS: 
    EXCLUD_FILE: 
  tasks:
    - name: Ensure the destination directory exists
      file:
        path: "{{ DEST_PATH  }}"
        state: directory

#    - name: Backup existing folder
#      command: "mv  {{ DEST_PATH }} {{ DEST_PATH }}_backup_{{ ansible_date_time.iso8601 }}"
#      when: folder_check.stat.exists

    - name: Copy files_mysql to remote hosts
      synchronize:
        # 需要在目录后面加上斜杠才是同步两个目录
        src: "{{ SRC_PATH }}/"
        dest: "{{ DEST_PATH }}/"
        recursive: yes
        archive: yes
        delete: yes
        checksum: yes
	      compress: yes
	      rsync_opts:
			    - "--exclude={{ EXCLUD_FILE }}"

    - name: start chat
      shell: "./{{ SCRIPT_NAME }} {{ JAR_NAME }} {{ RUN_OPTS }}"
      args:
        chdir: "{{ DEST_PATH }}"
			  executable: "/bin/bash"
    - name: "检查状态"
      shell: 'until curl -X GET -s -w "%{http_code}" -o /dev/null {{ HEALTH_API }} |grep  "200"; do sleep 1; done'
      args:
        executable: /bin/bash
      register: result
      until: result.stdout == "200"
      retries: 10 
      delay: 5 
      ignore_errors: true

```

```yaml
[web]
web1
web2
web3
web4
web5
web6
web7
web8
[web:vars]
ansible_ssh_user="root"
ansible_ssh_pass="ShUNC@2023!"

```

```yaml
172.16.165.76 web1
172.16.165.77 web2
172.16.165.78 web3
172.16.165.79 web4
172.16.165.80 web5
172.16.165.81 web6
172.16.165.82 web7
172.16.165.83 web8

172.16.165.87 rd-m
172.16.165.88 rd-s1
172.16.165.89 rd-s2

```