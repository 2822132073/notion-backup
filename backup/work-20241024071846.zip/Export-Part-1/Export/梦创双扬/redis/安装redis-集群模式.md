# 安装redis-集群模式

## 对编译后的文件进行处理

```bash
mkdir /data/redis/{conf,logs,bin,data} -p
mv src/{redis-benchmark,redis-check-aof,redis-check-rdb,redis-cli,redis-sentinel,redis-server} /data/redis/bin
```

## systemd文件

> `/etc/systemd/system/redis-server.service`
> 

```bash
[Unit]
Description=redis-server
After=network.target
[Service]
Type=forking
ExecStart= /data/redis/bin/redis-server /data/redis/conf/server.conf
PrivateTmp=true
[Install]
WantedBy=multi-user.target
```

```bash
systemctl daemon-reload
systemctl start redis-server
systemctl enable redis-server
```

## 配置文件

> 集群模式
> 

```bash
# NETWORK
bind 0.0.0.0
protected-mode no
port 6379
tcp-backlog 511
## unixsocket /tmp/redis.sock
## unixsocketperm 700
timeout 0
tcp-keepalive 300

# GENERAL
daemonize yes
supervised no
pidfile "/data/redis/redis.pid"
databases 16
always-show-logo yes

# log
loglevel notice
logfile "/data/redis/logs/redis.log"
## syslog-enabled no
## syslog-ident redis
## syslog-facility local0

slowlog-log-slower-than 10000
slowlog-max-len 128

# SNAPSHOTTING
dir "/data/redis/data"

save 900 1
save 300 10
save 60 10000

stop-writes-on-bgsave-error yes
rdbcompression yes
rdbchecksum yes
dbfilename "dump.rdb"
rdb-del-sync-files no

# REPLICATION
# repl-timeout 60
# master
repl-diskless-sync no
repl-diskless-sync-delay 5
repl-disable-tcp-nodelay yes
repl-backlog-size 1mb
repl-backlog-ttl 3600

# slave
# replicaof <masterip> <masterport>
# replicaof 192.168.3.6 6379
# masterauth <master-password>
masterauth "123456"
# masteruser <username>
# repl-ping-replica-period 10
repl-diskless-load disabled
replica-serve-stale-data yes
replica-read-only yes
replica-priority 100
# min-replicas-to-write 3
# min-replicas-max-lag 10
# replica-announce-ip 5.5.5.5
# replica-announce-port 1234
# replica-ignore-maxmemory yes

# KEYS TRACKING
# tracking-table-max-keys 1000000

# SECURITY
acllog-max-len 128
# aclfile /etc/redis/users.acl
# requirepass foobared
requirepass "123456"

# CLIENTS
# maxclients 10000

# MEMORY MANAGEMENT
# maxmemory <bytes>
# maxmemory-policy noeviction
# maxmemory-samples 5
# active-expire-effort 1

# LAZY FREEING
lazyfree-lazy-eviction no
lazyfree-lazy-expire no
lazyfree-lazy-server-del no
replica-lazy-flush no
lazyfree-lazy-user-del no

# THREADED I/O
# io-threads 4
# io-threads-do-reads no
# server_cpulist 0-7:2
# bio_cpulist 1,3
# aof_rewrite_cpulist 8-11
# bgsave_cpulist 1,10-11

# KERNEL OOM CONTROL
oom-score-adj no
oom-score-adj-values 0 200 800

# APPEND ONLY MODE
appendonly no
appendfilename "appendonly.aof"
appendfsync everysec
no-appendfsync-on-rewrite no
auto-aof-rewrite-percentage 100
auto-aof-rewrite-min-size 64mb
aof-load-truncated yes
aof-use-rdb-preamble yes

# LUA SCRIPTING
busy-reply-threshold 5000

# REDIS CLUSTER
cluster-enabled yes
cluster-config-file nodes-6379.conf
cluster-node-timeout 15000
# cluster-replica-validity-factor 10
# cluster-migration-barrier 1
# cluster-require-full-coverage yes
# cluster-replica-no-failover no
# cluster-allow-reads-when-down no
# cluster-announce-ip 10.1.1.5
# cluster-announce-port 6379
# cluster-announce-bus-port 6380

# LATENCY MONITOR
latency-monitor-threshold 0

# EVENT NOTIFICATION
notify-keyspace-events ""
# GOPHER SERVER
# gopher-enabled no

# ADVANCED CONFIG
hash-max-listpack-entries 512
hash-max-listpack-value 64
list-max-listpack-size -2
list-compress-depth 0
set-max-intset-entries 512
zset-max-listpack-entries 128
zset-max-listpack-value 64
hll-sparse-max-bytes 3000
stream-node-max-bytes 4kb
stream-node-max-entries 100
activerehashing yes
client-output-buffer-limit normal 0 0 0
client-output-buffer-limit replica 256mb 64mb 60
client-output-buffer-limit pubsub 32mb 8mb 60
# client-query-buffer-limit 1gb
# proto-max-bulk-len 512mb
hz 10
dynamic-hz yes
aof-rewrite-incremental-fsync yes
rdb-save-incremental-fsync yes
# lfu-log-factor 10
# lfu-decay-time 1

# ACTIVE DEFRAGMENTATION
# activedefrag no
# active-defrag-ignore-bytes 100mb
# active-defrag-threshold-lower 10
# active-defrag-threshold-upper 100
# active-defrag-cycle-min 1
# active-defrag-cycle-max 25
# active-defrag-max-scan-fields 1000
jemalloc-bg-thread yes

```

## 搭建集群

```bash
redis-cli --cluster create 172.16.165.111:6379 172.16.165.112:6379 172.16.165.113:6379 
```

## 为集群添加从节点

> 使用`redis-cli`命令进行控制，不然会出现断开连接的情况
> 
> 
> `Error: Server closed the connection
> not connected> info`
> 

```bash
redis-cli -a 123456 -h 127.0.0.1 -p 6379 cluster REPLICATE  
```

## 集群模式下的一些命令

### 进入集群模式

```bash
redis-cli -c -p 6379 -h 192.168.1.138 -a 123456
```

### 集群模式下查看集群信息

```bash
192.168.1.138:6379> CLUSTER INFO
cluster_state:ok
cluster_slots_assigned:16384
cluster_slots_ok:16384
cluster_slots_pfail:0
cluster_slots_fail:0
cluster_known_nodes:3
cluster_size:3
cluster_current_epoch:3
cluster_my_epoch:1
cluster_stats_messages_ping_sent:229
cluster_stats_messages_pong_sent:231
cluster_stats_messages_sent:460
cluster_stats_messages_ping_received:229
cluster_stats_messages_pong_received:229
cluster_stats_messages_meet_received:2
cluster_stats_messages_received:460
total_cluster_links_buffer_limit_exceeded:0
```

### 查看集群节点信息

```bash
192.168.1.138:6379> CLUSTER NODES
1fade7cf9953061d047bdbbcbf977aab6fefcd8c 192.168.1.141:6379@16379 master - 0 1728887996680 2 connected 5461-10922
2115a462189a73c643e53dbe62f97bad93c33bcc 192.168.1.138:6379@16379 myself,master - 0 1728887994000 1 connected 0-5460
6fcb81b98844ba25a418f80e1916547062e71d2c 192.168.1.144:6379@16379 master - 0 1728887995677 3 connected 10923-16383
```

```bash
# Example sentinel.conf

bind 0.0.0.0
protected-mode no
port 26379

daemonize yes
pidfile "/data/redis/redis-sentinel.pid"
dir "/data/redis/logs"
logfile "sentinel.log"

# sentinel announce-ip <ip>
# sentinel announce-port <port>

#sentinel monitor mymaster <ip> <redis-port> <quorum>
sentinel monitor mymaster 172.16.165.87 6379 1
# sentinel monitor mymaster 192.168.3.6 6379 1
#sentinel auth-pass mymaster <pass>
sentinel auth-pass mymaster b840fc02d524045429941cc15f59e41cb7be6c599
#sentinel auth-user mymaster <username>
sentinel auth-user mymaster default
# requirepass <password>
requirepass "b840fc02d524045429941cc15f59e41cb7be6c599"

sentinel deny-scripts-reconfig yes

sentinel resolve-hostnames yes
# Generated by CONFIG REWRITE
user default on sanitize-payload #de0fb48baaeb1d7bc8e4c8b4f355e45346888a2c9a5d0783dfa36ad418f67a1a ~* &* +@all
sentinel myid 0603d14de70ff3a0313ea916f08992163fafd328
sentinel config-epoch mymaster 2
sentinel leader-epoch mymaster 2
sentinel current-epoch 2
sentinel known-replica mymaster 172.16.165.89 6379
sentinel known-replica mymaster 172.16.165.88 6379
sentinel known-sentinel mymaster 172.16.165.88 26379 e7c4dd930c45dbd1ba808d80a1841e07148f5de5
sentinel known-sentinel mymaster 172.16.165.89 26379 5cc7cbb53d65d348208a1340bcb4d3c7a98acd86

latency-tracking-info-percentiles 50 99 99.9

```