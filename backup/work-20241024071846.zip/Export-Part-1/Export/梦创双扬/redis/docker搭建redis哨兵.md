# docker搭建redis哨兵

> 注意设置 volumes 以及 master 的地址
> 

```yaml
version: '2'

services:
  redis-master:
    image: 'bitnami/redis:7.2.4'
    user: root
    environment:
      REDIS_PASSWORD: 123456
    volumes:
    - /data/docker-redis/redis-master-data:/bitnami/redis/data
    ports:
      - 6379:6379
  redis-slave1:
    image: 'bitnami/redis:7.2.4'
    user: root
    environment:
      REDIS_REPLICATION_MODE: slave
      REDIS_MASTER_HOST: 192.168.1.148
      REDIS_MASTER_PORT_NUMBER: 6379
      REDIS_PASSWORD: 123456
      REDIS_MASTER_PASSWORD: 123456
    volumes:
    - /data/docker-redis/redis-slave1-data:/bitnami/redis/data
    ports:
      - 6380:6379
  redis-slave2:
    image: 'bitnami/redis:7.2.4'
    user: root
    environment:
      REDIS_REPLICATION_MODE: slave
      REDIS_MASTER_HOST: 192.168.1.148
      REDIS_MASTER_PORT_NUMBER: 6379
      REDIS_PASSWORD: 123456
      REDIS_MASTER_PASSWORD: 123456
    volumes:
    - /data/docker-redis/redis-slave2-data:/bitnami/redis/data
    ports:
      - 6381:6379

```

> 注意设置 volumes 以及 master 的地址
> 

```yaml
version: '2'
services:
  sentinel1:
    image: 'bitnami/redis-sentinel:7.2.4'
    user: root
    environment:
      REDIS_PASSWORD: 123456
      REDIS_SENTINEL_MASTER_NAME: mymaster
      REDIS_MASTER_SET: mymaster
      REDIS_SENTINEL_QUORUM: 2
      REDIS_MASTER_PASSWORD: 123456
      REDIS_MASTER_HOST: 192.168.1.148
      REDIS_MASTER_PORT_NUMBER: 6379
    volumes:
    - /data/docker-sentinel/sentinel-data-1:/bitnami/redis/data
    ports:
      - 26379:26379
  sentinel2:
    image: 'bitnami/redis-sentinel:7.2.4'
    user: root
    environment:
      REDIS_PASSWORD: 123456
      REDIS_SENTINEL_MASTER_NAME: mymaster
      REDIS_MASTER_SET: mymaster
      REDIS_SENTINEL_QUORUM: 2
      REDIS_MASTER_PASSWORD: 123456
      REDIS_MASTER_HOST: 192.168.1.148
      REDIS_MASTER_PORT_NUMBER: 6379
    volumes:
    - /data/docker-sentinel/sentinel-data-2:/bitnami/redis/data
    ports:
      - 26380:26379
  sentinel3:
    image: 'bitnami/redis-sentinel:7.2.4'
    user: root
    environment:
      REDIS_PASSWORD: 123456
      REDIS_SENTINEL_MASTER_NAME: mymaster
      REDIS_MASTER_SET: mymaster
      REDIS_SENTINEL_QUORUM: 2
      REDIS_MASTER_PASSWORD: 123456
      REDIS_MASTER_HOST: 192.168.1.148
      REDIS_MASTER_PORT_NUMBER: 6379
    volumes:
    - /data/docker-sentinel/sentinel-data-3:/bitnami/redis/data
    ports:
      - 26381:26379

```