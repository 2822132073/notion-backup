# 从原有的redis迁移数据到集群模式

## 环境

- 源数据库：redis-7.2.4(哨兵)
- 目标数据库：redis-7.2.4(集群)
- redisShake-4.2.0

[tair-opensource/RedisShake: RedisShake is a Redis data processing and migration tool. (github.com)](https://github.com/tair-opensource/RedisShake)

使用redisShake作为同步工具，可以实时的同步之间的数据。

## 下载

> 到github的页面上下载对应的安装包
> 

## 配置

> 解压之后，可以看到两个文件 `redis-shake , shake.toml` ，需要对 `shake.toml`  进行配置
> 

> redis-shake可以有三种模式从源端进行同步，对应三种 `Reader` ****，一般最常用的是 `Sync Reader` ****和 `RDB Reader` ,分别是模拟 slave 向源redis同步数据以及使用RDB文件恢复
> 

```bash
[sync_reader]
cluster = false            # set to true if source is a redis cluster
address = "192.168.1.148:6379" # when cluster is true, set address to one of the cluster node
username = ""              # keep empty if not using ACL
password = ""              # keep empty if no authentication is required
tls = false                #
sync_rdb = true            # set to false if you don't want to sync rdb
sync_aof = true            # set to false if you don't want to sync aof
prefer_replica = true # set to true if you want to sync from replica node
try_diskless = false       # set to true if you want to sync by socket and source repl-diskless-sync=yes

[redis_writer]
cluster = true # set to true if target is a redis cluster
sentinel = false           # set to true if target is a redis sentinel
master = ""                # set to master name if target is a redis sentinel
address = "192.168.1.138:6379" # when cluster is true, set address to one of the cluster node
username = ""              # keep empty if not using ACL
password = "123456"              # keep empty if no authentication is required
tls = false
off_reply = false          # turn off the server reply

```

> 还可以配置许多其他的配置，对指定的key进行过滤，还可以指定同步db，可以去官方文档看
> 

[快速上手 | RedisShake](https://tair-opensource.github.io/RedisShake/zh/guide/getting-started.html)

## 开始同步

```bash

```