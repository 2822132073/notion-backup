# jenkins添加ssh server

![image.png](jenkins%E6%B7%BB%E5%8A%A0ssh%20server%20128a04ce7f0c801ca972c87955ea35ba/image.png)

![image.png](jenkins%E6%B7%BB%E5%8A%A0ssh%20server%20128a04ce7f0c801ca972c87955ea35ba/image%201.png)

![image.png](jenkins%E6%B7%BB%E5%8A%A0ssh%20server%20128a04ce7f0c801ca972c87955ea35ba/image%202.png)

> 这个在最底下，需要向下滑，如果没有，需要查看是否安装插件
>