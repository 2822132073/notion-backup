# 政务内网java更新文档

如果需要将jar包更新到政务内网，需要有一下几步

## 一、将包传到172.16.165.93（ansible主机）

> 将包传输到该主机之后，一般会在`/home/wsupport`目录下
> 

```bash
# 如果你更新的是es-server就是将${application}替换为es-server
mv /home/wsupport/${JAR_NAME} /data/${application}/
```

## 二、修改对应JAR包的配置文件

> 如果你在更新的同时也需要更新配置文件，需要在 `172.16.165.93` 中的相同目录下，也修改对应的配置文件
> 

## 三、更新

> 使用ansible进行批量分发，需要指定JAR包名称，注意需要切换为root用户
> 

```bash
su - root
cd ~/ansible/
ansible-playbook -i  hosts  -e "JAR_NAME=${appcationName}" playbook/${playbookName}
# applicationName需要指定刚刚上传包的名称
# playbookName需要指定具体的playbook名称
# ai-server -> gr-ai-server.yml
# axchat -> gr-chat.yml
# es-server -> gr-es-server.yml
```