# PLG日志收集

[json | Grafana Loki documentation](https://grafana.com/docs/loki/latest/send-data/promtail/stages/json/)

![image.png](PLG%E6%97%A5%E5%BF%97%E6%94%B6%E9%9B%86%2010aa04ce7f0c805c99d0dabb33fc597c/image.png)

日志收集不同于elk，现在使用loki作为日志收集，使用promtail进行收集日志以及对需要的信息进行标签化

promtail

```yaml
server:
  http_listen_port: 9080
  grpc_listen_port: 0

positions:
  filename: /tmp/positions.yaml

clients:
  - url: http://172.16.165.93:3100/loki/api/v1/push

scrape_configs:
- job_name: system
  static_configs:
  - targets:
      - localhost
    labels:
      job: varlogs
      __path__: /var/log/*log
- job_name: java_logs
  static_configs:
  - targets:
      - localhost
    labels:
      hosts: web1
      job: axchat_log
      __path__: /data/axchat/logs/*/*.log
  pipeline_stages:
  - match:
      selector: '{job="axchat_log"}'
      stages:
      - multiline:
          firstline: '^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3} '
          max_wait_time: 5s
      - regex:
          expression: '^(?P<time>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}) (?P<threadName>\[\S+]) (?P<level>[\S]+) (?P<className>\S+)-(?P<message>[\s\S\n]*$)'
      - labels:
          time:
          threadName:
          level:
          className:
          message:
      - timestamp:
          source: time
          format: '2006-01-02 15:04:05.999'
          location: "UTC"
      - drop:
          older_than: 120h
          drop_counter_reason: "line_too_old"

```