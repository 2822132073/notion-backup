# nfs

## 安装

```yaml
 sudo apt update
 sudo apt install -y nfs-kernel-server nfs-common
```

## 配置

> /etc/exports
> 

> 确保共享目录有足够的权限，可以使用chmod -R 777
> 

```bash
/srv/nfs_share 192.168.1.0/24(rw,sync,no_subtree_check)
```

![image.png](nfs%2010ca04ce7f0c80858e98deb12b350edf/image.png)

## 启动

```bash
sudo exportfs -r
sudo systemctl start nfs-kernel-server
sudo systemctl enable nfs-kernel-server
```

## 客户端使用

### linux

> 安装—>创建挂载点—>挂载
> 

> 使用实际的ip进行挂载
> 

```bash
sudo apt install nfs-common
sudo mkdir /mnt/nfs_share
sudo mount 192.168.1.142:/srv/nfs_share /mnt/nfs_share
```

> 可以使用showmount查看主机有哪些挂载点
> 

```bash
showmount -e 192.168.1.142
```

### windows

> windows11 我的这个机器暂时无法找到方法解决，下面是使用powershell命令开启nfs客户端的命令
> 

> 如果需要挂载，按照常理来说，需要使用`mount \\192.168.1.142\data\nfs E:`
> 

```bash
netsh advfirewall firewall set rule group="网络发现" new enable=Yes
Enable-WindowsOptionalFeature -Online -FeatureName NFS-Administration
Enable-WindowsOptionalFeature -Online -FeatureName ServicesForNFS-ClientOnly
Enable-WindowsOptionalFeature -Online -FeatureName ClientForNFS-Infrastructure

```