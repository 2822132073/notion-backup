# python程序更新文档

## 将文件传到205

![image.png](python%E7%A8%8B%E5%BA%8F%E6%9B%B4%E6%96%B0%E6%96%87%E6%A1%A3%20123a04ce7f0c80529e7ac75ecced6480/image.png)

将更新包传输到205上，然后传输到 **政务网**的 **93** 机器上 **`/home/wsupport`**

## 复制到对应同步目录下

```yaml
mv /home/wsupport/${packageName} /data/ad_ar/
```

## 修改变量文件

```yaml
vim  /root/ansible/playbooks/vars/python.yml
# ZIP_FILE: ad_arr_202410181044.zip
修改上述变量为刚刚的包名
```

## 更新

```yaml
ansible-playbook /root/ansible/playbooks/gr-python-advance-arrange.yml
```