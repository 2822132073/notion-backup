# nginx

/etc/security/limits.conf

```yaml
* soft nofile 65535
* hard nofile 65535
* soft noproc 65535
* hard noproc 65535
# End of file
* soft core 0
* hard core 0
```

```yaml
ulimit -u 65535
ulimit -n 65535
```

> 全局块
> 

```bash
worker_processes 8;
worker_rlimit_nofile 65535;
```

> event
> 

```bash
events {
    worker_connections 65535;
}
```

## nginx的一些安全优化

```bash
server {
    listen       443 ssl;
    server_name  localhost;

    ssl_certificate      /etc/nginx/cert.d/im.jbs.sh.gov.cn.crt;
    ssl_certificate_key  /etc/nginx/cert.d/im.jbs.sh.gov.cn.key;
    proxy_redirect http://$host/ https://$host:$server_port/;
    ssl_ciphers  ECDHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES128-SHA256:ECDHE-ECDSA-AES256-SHA384:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384;

    autoindex off;

    proxy_buffering off;
    proxy_http_version 1.1;
    chunked_transfer_encoding on;
    proxy_read_timeout 600s;
    proxy_set_header Host $host;
    proxy_set_header Cookie $http_cookie;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    add_header Cache-Control "no-store, no-cache, must-revalidate";
    add_header Strict-Transport-Security 'max-age=15552000'; 
    add_header X-XSS-Protection 1;
    add_header X-Content-Type-Options nosniff;
    add_header Content-Security-Policy "default-src 'self' 'https://jbs.sh.gov.cn'; script-src 'self' 'unsafe-inline' 'unsafe-eval' 'https://jbs.sh.gov.cn'; style-src 'self' 'unsafe-inline' 'https://jbs.sh.gov.cn'";

}
```

[244](nginx%20106a04ce7f0c80b7aee3df1019bfd905/244%2010ea04ce7f0c80b0bbc5e62e6f32b754.md)