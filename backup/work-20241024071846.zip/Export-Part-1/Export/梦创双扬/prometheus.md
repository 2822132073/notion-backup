# prometheus

[安装相关](prometheus%200ffa04ce7f0c80bb894ccb8a2519b70b/%E5%AE%89%E8%A3%85%E7%9B%B8%E5%85%B3%2010ea04ce7f0c80769fb3facda6718450.md)

[监控规则](prometheus%200ffa04ce7f0c80bb894ccb8a2519b70b/%E7%9B%91%E6%8E%A7%E8%A7%84%E5%88%99%2010ea04ce7f0c80e5a12ed6837c05f073.md)