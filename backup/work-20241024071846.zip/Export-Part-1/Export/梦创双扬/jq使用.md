# jq使用

### jq从环境变量中获取变量

当想动态修改json文件中的某个值，我们可以在环境变量中设置，然后jq读取环境变量的值，但是，正常的在jq中使用环境变量是有问题的，例如一下例子

```python
root@ng-105:/data/package# export VERSION=1.3.99
root@ng-105:/data/package# cat /data/im/config.json | jq  '.android.version=$VERSION'
jq: error: $VERSION is not defined at <top-level>, line 1:
.android.version=$VERSION                 
jq: 1 compile error
```

> 会报错，说明，jq中引用的变量不是在环境变量中取得的，我们需要使用 `--arg` 来设置变量
> 

```python
root@ng-105:/data/package# cat /data/im/config.json | jq --arg newVersion $VERSION '.android.version=$newVersion' |jq .android.version
"1.3.99"
```