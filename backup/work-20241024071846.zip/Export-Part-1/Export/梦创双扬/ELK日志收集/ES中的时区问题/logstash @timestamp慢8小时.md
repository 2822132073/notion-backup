# logstash @timestamp慢8小时

```yaml
 ruby {   
   code => "event.set('timestamp', event.get('@timestamp').time.localtime + 8*60*60)"   
 }  
 ruby {  
   code => "event.set('@timestamp',event.get('timestamp'))"  
 }  
```

Ai给的代码解释

1. 第一个 Ruby 代码块：
    - `code => "event.set('timestamp', event.get('@timestamp').time.localtime + 8*60*60)"`
        - `event.get('@timestamp')`获取输入事件中的`@timestamp`字段的值，这个值应该是一个时间戳。
        - `.time.localtime`将这个时间戳转换为本地时间。
        - `+ 8*60*60`表示在本地时间的基础上加上 8 小时的秒数（因为 1 小时有 60 分钟，1 分钟有 60 秒，所以 8 小时就是 `8*60*60` 秒）。
        - 最后，使用 `event.set('timestamp',...)`将处理后的时间保存到一个新的字段名为`timestamp`中。
2. 第二个 Ruby 代码块：
    - `code => "event.set('@timestamp',event.get('timestamp'))"`
        - 这一步将上一步处理后保存在`timestamp`字段中的时间值赋回给`@timestamp`字段，覆盖原来的时间戳。