# ES中的时区问题

[Elasticsearch 滞后8个小时等时区问题，一网打尽！-腾讯云开发者社区-腾讯云](https://cloud.tencent.com/developer/article/1860944)

logstash在向es中写入数据时，会将时间转换为 UTC 时间，这个是无法配置的，之前可以通过设置一些ruby代理来设置这个值，但是这个方法其实是不好的，这样会造成一些其他的客户端的时间显示异常。我觉得好的方法是在客户端进行处理，例如

1. kibana可以从设置时区，从es读取的是UTC时间，然后，再将其转到其他时间
2. 如果我们需要使用客户端对其中的数据查询，可以使用timezone进行设置

## logstash对时间的处理

[logstash @timestamp慢8小时](ES%E4%B8%AD%E7%9A%84%E6%97%B6%E5%8C%BA%E9%97%AE%E9%A2%98%20127a04ce7f0c80208aaaf0a8f371226f/logstash%20@timestamp%E6%85%A28%E5%B0%8F%E6%97%B6%20126a04ce7f0c80d280f7ee9fd0900c4f.md)

如果还是想让时间变成UTC+8，我们可以通过ruby代理。

## 程序对他的处理

```python
import logging
import os

from elasticsearch import Elasticsearch

from datetime import datetime, timedelta

end_time_file = "/data/python/end_time_test"

logging.basicConfig(filemode="a", level=logging.DEBUG,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
current_date = datetime.now().strftime('%Y.%m.%d')

es = Elasticsearch(
    ['http://127.0.0.1:9200'],
    sniff_on_start=True,
    sniff_on_node_failure=True,
    min_delay_between_sniffing=60
)

def parse_time_with_file(file_path):
    with open(file_path, 'r') as f:
        lines = f.readline()
    date = datetime.strptime(lines, '%Y-%m-%dT%H:%M:%S')
    return date

def write_str_to_tile(s, file_path):
    with open(file_path, 'w') as f:
        f.write(s)
        logging.info(f'写入{s} -> {file_path}')
    return

if os.path.exists(end_time_file):
    start_time = parse_time_with_file(end_time_file)
    end_time = datetime.now()
else:
    end_time = datetime.now()
    start_time = end_time - timedelta(hours=3)

start_time_query_str = start_time.strftime('%Y-%m-%dT%H:%M:%S')
end_time_query_str = end_time.strftime('%Y-%m-%dT%H:%M:%S')

def chat_warning():
    query = {
        "query": {
            "bool": {
                "must": [
                    {
                        "match": {
                            "level": "error"
                        }
                    }
                ],
                "must_not": [
                    {
                        "match": {
                            "message": "Connection reset by peer"
                        }
                    }
                ],
                "filter": {
                    "range": {
                        "@timestamp": {
                            "gte": start_time_query_str,
                            "lte": end_time_query_str,
                            "time_zone": "+08:00"
                        }
                    }
                }
            }
        }
    }
    logging.info(query)
    try:
        index_name = "log-java-ai-" + current_date
        search_result = es.search(index=index_name, body=query)
        logging.info(
            f'{index_name} - {start_time} - {end_time}: 共有 {search_result["hits"]["total"]["value"]} 条记录！')
        if search_result["hits"]["total"]["value"] > 0:
            logging.info(search_result["hits"]["total"]["value"])
    except Exception as e:
        logging.error(e)

chat_warning()
```

直接统一的对es的UTC时间进行处理就行。