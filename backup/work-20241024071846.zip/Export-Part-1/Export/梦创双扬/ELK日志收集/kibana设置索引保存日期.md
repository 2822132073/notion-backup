# kibana设置索引保存日期

## 添加索引模板

![image.png](kibana%E8%AE%BE%E7%BD%AE%E7%B4%A2%E5%BC%95%E4%BF%9D%E5%AD%98%E6%97%A5%E6%9C%9F%2011ba04ce7f0c80698279d0d8951159e2/image.png)

![image.png](kibana%E8%AE%BE%E7%BD%AE%E7%B4%A2%E5%BC%95%E4%BF%9D%E5%AD%98%E6%97%A5%E6%9C%9F%2011ba04ce7f0c80698279d0d8951159e2/image%201.png)

![image.png](kibana%E8%AE%BE%E7%BD%AE%E7%B4%A2%E5%BC%95%E4%BF%9D%E5%AD%98%E6%97%A5%E6%9C%9F%2011ba04ce7f0c80698279d0d8951159e2/image%202.png)

填写这两个，使用正则表达式，写出需要匹配的索引。

## 添加**索引生命周期策略**

![image.png](kibana%E8%AE%BE%E7%BD%AE%E7%B4%A2%E5%BC%95%E4%BF%9D%E5%AD%98%E6%97%A5%E6%9C%9F%2011ba04ce7f0c80698279d0d8951159e2/image%203.png)

![image.png](kibana%E8%AE%BE%E7%BD%AE%E7%B4%A2%E5%BC%95%E4%BF%9D%E5%AD%98%E6%97%A5%E6%9C%9F%2011ba04ce7f0c80698279d0d8951159e2/image%204.png)

![image.png](kibana%E8%AE%BE%E7%BD%AE%E7%B4%A2%E5%BC%95%E4%BF%9D%E5%AD%98%E6%97%A5%E6%9C%9F%2011ba04ce7f0c80698279d0d8951159e2/image%205.png)

![image.png](kibana%E8%AE%BE%E7%BD%AE%E7%B4%A2%E5%BC%95%E4%BF%9D%E5%AD%98%E6%97%A5%E6%9C%9F%2011ba04ce7f0c80698279d0d8951159e2/image%206.png)

选择对应的模板模式