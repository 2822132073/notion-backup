# filter

i**f:**

[Logstash configuration examples | Logstash Reference [7.17] | Elastic](https://www.elastic.co/guide/en/logstash/7.17/config-examples.html#using-conditionals)

> 从`filebeat`读取数据，然后使用`add_field`添加一个字段，这个字段的值是原来其中的`fields`字段，然后使用`json`解析这个字段，相当于解析这个字段，将其中的元素提取到上层。然后再删除这两个字段。这样做的目的是，`logstash`无法解析`filebeat`给出的数据，只能复制一次才能进行解析
> 

## grok

[GROK的模式说明以及常用语法_日志服务(SLS)-阿里云帮助中心](https://help.aliyun.com/zh/sls/user-guide/grok-patterns)

### 自定义模式

> 使用`(?<field_name>the pattern here)` 自定义模式名，例如 `(?<msg>.*)` ，如果不写 `field_name` ，匹配到的内容将被丢弃。
> 

```json
%{TIMESTAMP_ISO8601:timestamp}%{SPACE}\[%{DATA:thread}\]%{SPACE}%{LOGLEVEL:level}%{SPACE}\[%{DATA:class}\]%{SPACE}>>>%{SPACE}%{GREEDYDATA:message}
```

## 配置实例

```json
filter {
  mutate {
    add_field => {"mid_fields"=>"%{fields}"}
  }
  json {
    source => "mid_fields"
  }
  mutate {
    gsub => [
      "message", ".{1}\[0;39m", "",
      "message", ".{1}\[35m", "",
      "message", ".{1}\[32m", "",
      "message", ".{1}\[36m", ""
    ]
    remove_field => ["agent","tags","input","ecs","@version","mid_fields","fields","host"]
  }
  if [message] =~ ".*ERROR.*" {
    grok {
      match => { "message" => "%{TIMESTAMP_ISO8601:timestamp}%{SPACE}\[%{DATA:thread}\]%{SPACE}%{LOGLEVEL:level}%{SPACE}\[%{DATA:class}\]%{SPACE}>>>%{SPACE}%{GREEDYDATA:msg}"}
    }
  }else {
    grok {
      match => { "message" => "%{TIMESTAMP_ISO8601:timestamp}%{SPACE}\[%{DATA:thread}\]%{SPACE}%{LOGLEVEL:level}%{SPACE}\[%{DATA:class}\]%{SPACE}>>>%{SPACE}%{GREEDYDATA:msg}"}
    }
  }
  mutate {
    remove_field => ["message"]
  }
}

```

> 这段配置做了如下几个操作：
1. 添加一个字段 `mid_fields` ，它的值是filebeat配置文件中fields的值
2. 解析这个字段，相当于把这个字段展开，就像是：将 `{"a":{"e":1,"g":2}}` 中的e和g提取出来
3. 使用`mutate`将`message`字段中一些与颜色相关的替换掉，然后删除一些字段
4. 判断日志中的关键字，然后使用不同的`grok`去匹配
5. 最后删除匹配完成的`message`字段
> 

```json
%{TIMESTAMP_ISO8601:timestamp}%{SPACE}%{LOGLEVEL:level}%{SPACE}%{NUMBER}%{SPACE}---%{SPACE}\[%{DATA:thread}\]%{DATA:class}%{SPACE}:%{GREEDYDATA:msg}
```