# logstash时区设置

在进行日志收集的时候，有的时候收集的时间与日志产生的时间有偏差，所以我们需要使用日志的时间对logstash默认的@timestamp进行重写，这样就避免了这个问题。

但是在使用logstash的date模块时，会出现很多问题，例如：

```json
{
          "class" : "com.dd.chat.netty.handler.WebSocketServerHandler  ",
          "@timestamp" : "2024-10-22T10:12:33.075Z",
          "msg" : "新链接加入/100.97.124.1:43135,id为00163efffe000677-0027acf9-00026401-abde6b4c61aa1a75-d2932e88 ",
          "Mtimestamp" : "2024-10-22T02:12:33.075Z",
          "LogTimestamp":"2024-10-22 10:12:33",
          "log" : {
            "offset" : 1349359935,
            "file" : {
              "path" : "/data/axchat/start.log"
            }
          },
          "application" : "axchat",
          "level" : "INFO",
          "thread" : "nioEventLoopGroup-6-16",
          "message" : "2024-10-22 10:12:33 [nioEventLoopGroup-6-16] INFO  [com.dd.chat.netty.handler.WebSocketServerHandler  ] ---- 新链接加入/100.97.124.1:43135,id为00163efffe000677-0027acf9-00026401-abde6b4c61aa1a75-d2932e88 ",
          "environment" : "production"
   },
```

> 这里的@timestamp暂时时准确的，但是也会有出现不准确的问题
> 

我们使用如下配置对他进行处理，上面的日志记录，是对日志处理后的结果

```json
input {
  beats {
    port => "9900"
  }
}
filter {
   ruby {
     code => "event.set('MidTimestamp', event.get('@timestamp').time.localtime + 8*60*60)"
   }
   ruby {
     code => "event.set('@timestamp',event.get('MidTimestamp'))"
   }
   mutate {
     add_field => {"mid_fields"=>"%{fields}"}
   }
  json {
    source => "mid_fields"
  }
  mutate {
    remove_field => ["agent","tags","input","ecs","@version","mid_fields","fields"]
  }
  if [application] == "axchat" {
    grok {
      match => { "message" => "%{TIMESTAMP_ISO8601:LogTimestamp}%{SPACE}\[%{DATA:thread}\]%{SPACE}%{LOGLEVEL:level}%{SPACE}\[%{DATA:class}\]%{SPACE}----%{SPACE}%{GREEDYDATA:msg}"}
    }
    date {
      match => ["LogTimestamp", "yyyy-MM-dd HH:mm:ss"]
      target => "Mtimestamp" 
    }
    mutate {
      remove_field => ["host","MidTimestamp"]
    }
  }
}
output {
  if [application] == "axchat" {
    elasticsearch { 
      hosts => ["127.0.0.1:9200"] 
      index => "log-java-chat-%{+YYYY.MM.dd}"
    }
  }
}

```

这里着重看 date 

```json
    date {
      match => ["LogTimestamp", "yyyy-MM-dd HH:mm:ss"]
      target => "Mtimestamp" 
    }
```

> 这里设置了解析的格式，以及，将值赋予给哪个字段，但是，实际解析的结果却是比实际慢了8个小时，我的推测是：这里的解析后时间是显示的UTC时间，设置的时区的意思是，这里的时间是哪里的时间，而我们主机的时区是UTC+8时间，所以需要 -8 才是需要显示的时间，所以解决的方法是：设置时区为UTC，这样就可以不做任何处理。
> 

为了证实我的猜想，我将时区设置为 Africa/Bangui ，这个时间是 UTC+1 ，按照以上推测，解析出来的时间，就是比实际时间少一小时。

## 解决方案

> 可以根据以上推测，可以通过时区对解析的时间进行加减
> 

```json
    date {
      match => ["LogTimestamp", "yyyy-MM-dd HH:mm:ss"]
      target => "Mtimestamp" 
      timezone => "UTC"
    }
```