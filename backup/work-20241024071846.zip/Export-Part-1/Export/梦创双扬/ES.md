# ES

## elasticsearch-head无法使用

***显示： elasticsearch中head连不上es，集群健康值: 未连接***

解决方法：

> 修改es配置，添加如下配置，允许跨域
> 

```yaml
http.cors.enabled: true
http.cors.allow-origin: "*"
```

## es安装过程中需要修改的系统配置

1. max virtual memory areas vm.max_map_count [65530] is too low, increase to at least [262144]

```yaml
# 向 /etc/sysctl.conf 中添加如下内容

vm.max_map_count = 262144
# 然后使其生效
echo "vm.max_map_count = 262144" >>/etc/sysctl.conf
sudo sysctl -p
```

1. **memory locking requested for elasticsearch process but memory is not locked**

> 也可以直接将 **bootstrap.memory_lock: false**
> 

```yaml
1. 修改文件/etc/elasticsearch/elasticsearch.yml，上面那个报错就是开启后产生的，如果开启还要修改其它系统配置文件 

bootstrap.memory_lock: true

2. 修改文件/etc/security/limits.conf，最后添加以下内容。      

* soft nofile 65536
* hard nofile 65536
* soft nproc 32000
* hard nproc 32000
* hard memlock unlimited
* soft memlock unlimited

3. 修改文件 /etc/systemd/system.conf ，分别修改以下内容。

DefaultLimitNOFILE=65536
DefaultLimitNPROC=32000
DefaultLimitMEMLOCK=infinity
```

## 配置文件

```yaml
cluster.name: es-cluster-1
node.name: node-1
path.data: /home/u/elasticsearch-7.17.4/data
path.logs: /home/u/elasticsearch-7.17.4/logs
bootstrap.memory_lock: false
network.host: 192.168.1.194
http.port: 9200
discovery.seed_hosts: ["127.0.0.1"]
cluster.initial_master_nodes: ["node-1"]
http.cors.enabled: true
http.cors.allow-origin: "*"
```

## systemd

```yaml
[Unit]
Description=Elasticsearch
Documentation=http://www.elastic.co
Wants=network-online.target
After=network-online.target

[Service]
User=elastic
Group=elastic
ExecStart=/data/elasticsearch/bin/elasticsearch -d -p /data/elasticsearch/pid/elasticsearch.pid
StandardOutput=journal
StandardError=inherit
LimitNOFILE=65536
LimitNPROC=4096
LimitAS=infinity
LimitFSIZE=infinity
TimeoutStopSec=0
KillSignal=SIGTERM
KillMode=process
SendSIGKILL=no
SuccessExitStatus=143
 
[Install]
WantedBy=multi-user.target
```

> 需要在es目录下创建pid文件夹，并且修改文件夹权限
>