# Weekly To-do List

Add your weekly to-do’s. You can always add more by typing `/to-do` in an empty space. Click this button to create a fresh set of to-do’s for a new week. You can drag any old to-do’s from last week to the new week. ↓

# March 4 - March 9

---

### Mon

- [x]  Call Mom
- [x]  Book appt
- [ ]  

### Tues

- [ ]  
- [x]  
- [x]  

### Wed

- [ ]  
- [ ]  
- [ ]  

### Thur

- [ ]  
- [ ]  
- [ ]  

### Fri

- [ ]  
- [ ]  
- [ ]  

### Sat

- [ ]  
- [ ]  
- [ ]  

### Sun

- [ ]  
- [ ]  
- [ ]