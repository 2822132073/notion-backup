# ELK日志收集

https://www.elastic.co/guide/en/elasticsearch/reference/7.17/docker.html

https://www.elastic.co/guide/en/kibana/7.17/index.html

https://github.com/bitnami/containers

## 单节点es

> 如果指定的数据目录中有数据，请确定目录中数据无用后，删除
> 

> 需要创建指定目录的，还需要给予`chmod -R 777 /data/es`,这步没必要去省略，已经找了很多方法，没被办法避免
包括 -u 0:0
> 

> cat single-node.sh
> 

```bash
#!/bin/bash
sudo docker run -d --rm  -p 9200:9200 \
-p 9300:9300 \
-e ES_JAVA_OPTS="-Xms64m -Xmx512m" \
-v /data/es/single/data/:/usr/share/elasticsearch/data/\
-v /data/es/single/data/plugins:/usr/share/elasticsearch/plugins\
--name es-single \
-e "discovery.type=single-node"\
elasticsearch:7.17.24
```

### kibana

[二进制](ELK%E6%97%A5%E5%BF%97%E6%94%B6%E9%9B%86%2010ca04ce7f0c80a9bfc0e75feaf832a1/%E4%BA%8C%E8%BF%9B%E5%88%B6%2011aa04ce7f0c8074aad5c13b801d6cad.md)

```bash
#!/bin/bash
sudo docker run  -d --name kibana -p 5601:5601 --link es-single:es -e "ELASTICSEARCH_HOSTS=http://es:9200" -d kibana:7.17.24
```

> 需要开启中文或者需要修改某些配置的话，需要配置文件，可以先使用一下命令先启动，然后，拷贝其中的文件出现
> 

```docker
docker cp  kibana:/usr/share/kibana/config/kibana.yml .
mkdir /data/kibana
mv conf /data/kibana
```

> 然后使用这个文件夹的配置文件,下面是中文配置
> 

```docker
i18n.locale: "zh-CN"
```

> 然后使用，下面的脚本启动
> 

```docker
sudo docker run -d --rm --name kibana -p 5601:5601 -v /data/kibana/config:/usr/share/kibana/config --link es-single:es -e "ELASTICSEARCH_HOSTS=http://es:9200" kibana:7.17.24
```

## filebeat

[Filebeat quick start: installation and configuration | Filebeat Reference [7.17] | Elastic](https://www.elastic.co/guide/en/beats/filebeat/7.17/filebeat-installation-configuration.html)

> 如果filebeat直接输出到es，并且设置了 `index` 选项，需要按照下面来设置，不然无法输出到elasticsearch
> 

```jsx
output.elasticsearch:
  hosts: ["http://172.16.165.93:9200"]
  preset: latency
  index: filebeat-log-%{+yyyy.MM.dd}
setup.template.name: "filebeat"
setup.template.pattern: "filebeat-*"
```

> 这个 `pattern` 的表达式必须覆盖上面写的 `index` 的格式 ，不然也会出错
> 

```yaml
filebeat.inputs:
- type: log
  id: system
	# 是否开启配置
  enabled: false
  paths:
    - /var/log/*.log
- type: log
  enabled: true
  paths:
    - /data/axchat/start.log
# 如果发现无法采集日志，可以尝试关闭这个配置，可能是正则写错了一直无法采集到第一行，所以没有日志
  multiline.pattern: '^\d{4}-'
  multiline.negate: true
  multiline.match: after
  fields:  
    application: axchat
    environment: production

```

## logstash

logstash和应用有关的有两个文件

- **`logstash.yml` ：主要配置一些与logstash的相关内容，比如日志的位置大小，等一些东西**[logstash.yml | Logstash Reference [7.17] | Elastic](https://www.elastic.co/guide/en/logstash/7.17/logstash-settings-file.html)
- **`pipelines.yml` ：配置pipelines相关的内容，解析日志格式等一些东西**

在启动logstash时，logstash.yml不需要指定，应用应该是自动去找启动命令目录下的config/logstash.yml，然后读取其中配置。

pipelines.yml在哪里设置，我还没有试出来。这个文件主要的作用是给不同的pipeline设置不同的id，以及一些配置。

[filter](ELK%E6%97%A5%E5%BF%97%E6%94%B6%E9%9B%86%2010ca04ce7f0c80a9bfc0e75feaf832a1/filter%2011ba04ce7f0c80cd9101c6c416b2e666.md)

[Ruby filter plugin | Logstash Reference [8.15] | Elastic](https://www.elastic.co/guide/en/logstash/current/plugins-filters-ruby.html)

[Installing Logstash | Logstash Reference [7.17] | Elastic](https://www.elastic.co/guide/en/logstash/7.17/installing-logstash.html)

[Logstash解析嵌套JSON格式数据&常见时间操作_logstash json-CSDN博客](https://blog.csdn.net/XMZHSY/article/details/121550687)

```jsx
#!/bin/bash
WORKING_DIR=`pwd`
SERVER_NAME="logstash"
HOME="/data/${SERVER_NAME}"
CONFIG_FILE="prometheus.yml"
ln -s ${WORKING_DIR} ${HOME}
JAVA_HOME=${WORKING_DIR}/jdk
cat >/usr/lib/systemd/system/${SERVER_NAME}.service <<EOF
[Unit]
Description=${SERVER_NAME}
After=network.target
[Service]
ExecStart=${HOME}/bin/${SERVER_NAME}

[Install]

WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl start ${SERVER_NAME}
systemctl enable ${SERVER_NAME}
systemctl status ${SERVER_NAME}

```

[kibana设置索引保存日期](ELK%E6%97%A5%E5%BF%97%E6%94%B6%E9%9B%86%2010ca04ce7f0c80a9bfc0e75feaf832a1/kibana%E8%AE%BE%E7%BD%AE%E7%B4%A2%E5%BC%95%E4%BF%9D%E5%AD%98%E6%97%A5%E6%9C%9F%2011ba04ce7f0c80698279d0d8951159e2.md)