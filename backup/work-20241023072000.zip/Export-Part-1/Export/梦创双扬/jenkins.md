# jenkins

[jenkins添加ssh server](jenkins%20128a04ce7f0c80939c18df55774fe8bd/jenkins%E6%B7%BB%E5%8A%A0ssh%20server%20128a04ce7f0c801ca972c87955ea35ba.md)