# alertmanager通过dingding告警

[钉钉 dingding dingtalk prometheus报警模板template_prometheus-webhook-dingtalk templates-CSDN博客](https://blog.csdn.net/qq_36648860/article/details/115767873#:~:text=##%20Request#:~:text=##%20Request)

## 安装prometheus-webhook-dingtalk

[https://github.com/timonwong/prometheus-webhook-dingtalk](https://github.com/timonwong/prometheus-webhook-dingtalk)

可以使用二进制模式和docker安装，这里就写一个二进制模式

> 解压进入目录，将这个脚本复制到下面的目录中，然后执行，注意，需要修改HOME变量位置，以及编写config.yml
> 

```jsx
#!/bin/bash
WORKING_DIR=`pwd`
SERVER_NAME=dingding_webhook
HOME="/data/${SERVER_NAME}"

ln -s  ${WORKING_DIR} ${HOME}
cat >/usr/lib/systemd/system/${SERVER_NAME}.service <<EOF
[Unit]
Description=${SERVER_NAME}
After=network.target

[Service]
ExecStart=${HOME}/prometheus-webhook-dingtalk --config.file=${HOME}/config.yml

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl start ${SERVER_NAME}
systemctl status ${SERVER_NAME}
systemctl enable ${SERVER_NAME}
```

---

## 配置webhook

> 这里的secret是加签的值，添加dingding机器人是选择加密访问为加签时，会出现一个SEC值，这里的message是固定的值
> 

```jsx
templates:
  - /data/dingding_webhook/cn.tmpl
targets:
  webhook1:
    url: https://oapi.dingtalk.com/robot/send?access_token=xxxxxxxxxxxxxxxxxxxxxx
    # secret for signature
    secret: SECxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    message:
      title: '{{ template "ding.link.title" . }}'
      text: '{{ template "ding.link.content" . }}'

```

![image.png](alertmanager%E9%80%9A%E8%BF%87dingding%E5%91%8A%E8%AD%A6%20119526468f4b801fb8aff7eb7bb1a21b/image.png)

---

## 配置模板

> 这就是一个通用的模板
> 

```jsx
{{ define "__subject" }}[{{ .Status | toUpper }}{{ if eq .Status "firing" }}:{{ .Alerts.Firing | len }}{{ end }}] {{ .GroupLabels.SortedPairs.Values | join " " }} {{ if gt (len .CommonLabels) (len .GroupLabels) }}({{ with .CommonLabels.Remove .GroupLabels.Names }}{{ .Values | join " " }}{{ end }}){{ end }}{{ end }}
{{ define "__alertmanagerURL" }}{{ .ExternalURL }}/#/alerts?receiver={{ .Receiver }}{{ end }}

{{ define "__text_alert_list" }}{{ range . }}
**Labels**
{{ range .Labels.SortedPairs }}> - {{ .Name }}: {{ .Value | markdown | html }}
{{ end }}
**Annotations**
{{ range .Annotations.SortedPairs }}> - {{ .Name }}: {{ .Value | markdown | html }}
{{ end }}
**Source:** [{{ .GeneratorURL }}]({{ .GeneratorURL }})
{{ end }}{{ end }}

{{ define "default.__text_alert_list" }}{{ range . }}
---
**告警级别:** {{ .Labels.severity | upper }}

**告警标题:** {{ .Annotations.title }}

**触发时间:** {{ dateInZone "2006.01.02 15:04:05" (.StartsAt) "Asia/Shanghai" }}

**事件信息:** 
{{ range .Annotations.SortedPairs }}> - {{ .Name }}: {{ .Value | markdown | html }}

{{ end }}

**事件标签:**
{{ range .Labels.SortedPairs }}
{{ if and (ne (.Name) "severity") (ne (.Name) "summary") (ne (.Name) "team") }}> - {{ .Name }}: {{ .Value | markdown | html }}
{{ end }}{{ end }}
{{ end }}
{{ end }}
{{ define "default.__text_alertresovle_list" }}{{ range . }}
---
**告警级别:** {{ .Labels.severity | upper }}

**告警标题:** {{ .Labels.Title}}

**触发时间:** {{ dateInZone "2006.01.02 15:04:05" (.StartsAt) "Asia/Shanghai" }}

**结束时间:** {{ dateInZone "2006.01.02 15:04:05" (.EndsAt) "Asia/Shanghai" }}

**事件信息:**
{{ range .Annotations.SortedPairs }}> - {{ .Name }}: {{ .Value | markdown | html }}

{{ end }}

**事件标签:**
{{ range .Labels.SortedPairs }}{{ if and (ne (.Name) "severity") (ne (.Name) "summary") (ne (.Name) "team") }}> - {{ .Name }}: {{ .Value | markdown | html }}
{{ end }}{{ end }}
{{ end }}
{{ end }}

{{/* Default */}}
{{ define "default.title" }}{{ template "__subject" . }}{{ end }}
{{ define "default.content" }}#### \[{{ .Status | toUpper }}{{ if eq .Status "firing" }}:{{ .Alerts.Firing | len }}{{ end }}\] **[{{ index .GroupLabels "alertname" }}]({{ template "__alertmanagerURL" . }})**
{{ if gt (len .Alerts.Firing) 0 -}}

**====侦测到故障====**
{{ template "default.__text_alert_list" .Alerts.Firing }}

{{- end }}

{{ if gt (len .Alerts.Resolved) 0 -}}
{{ template "default.__text_alertresovle_list" .Alerts.Resolved }}

{{- end }}
{{- end }}

{{/* Legacy */}}
{{ define "legacy.title" }}{{ template "__subject" . }}{{ end }}
{{ define "legacy.content" }}#### \[{{ .Status | toUpper }}{{ if eq .Status "firing" }}:{{ .Alerts.Firing | len }}{{ end }}\] **[{{ index .GroupLabels "alertname" }}]({{ template "__alertmanagerURL" . }})**
{{ template "__text_alert_list" .Alerts.Firing }}
{{- end }}

{{/* Following names for compatibility */}}
{{ define "ding.link.title" }}{{ template "default.title" . }}{{ end }}
{{ define "ding.link.content" }}{{ template "default.content" . }}{{ end }}

```

> 可以通过 `.Annotations` 访问`prometheus rule`规则中的`annotation`
>