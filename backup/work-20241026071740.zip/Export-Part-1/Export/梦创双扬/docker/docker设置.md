# docker设置

```python
cat >/etc/docker/daemon.json<<EOF
{
  "data-root": "/data/docker",
  "registry-mirrors": [
    "https://docker.m.daocloud.io"
  ],
   "log-driver":"json-file",
  "log-opts": {"max-size":"500m", "max-file":"3"},
  "live-restore": true
}
EOF

```

1. 设置了docker数据存储地点，根目录，包括镜像、容器、卷和网络等。默认情况下，这个目录位于 /var/lib/docker。
2. 设置了拉取的镜像源
3. 设置了日志的格式
4. 设置了每个容器的日志的大小以及最大个数
5. 设置了在docker重启时，不重启容器
6. 

```python

{
  "registry-mirrors": [
    "https://docker.m.daocloud.io"
  ],
   "log-driver":"json-file",
  "log-opts": {"max-size":"60m", "max-file":"5"},
  "live-restore": true,
}

```